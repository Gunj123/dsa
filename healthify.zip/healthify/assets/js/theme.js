(function ($) {
    'use strict';

    /*---WOW active js ---- */
    new WOW().init();

    

})(jQuery);



// slider_1

var owl = $('.owl-carousel-banner');
owl.owlCarousel({
    padding: 0,
    margin: 0,
    loop: true,
    nav: true,
    dots: true,
    navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
    autoplay: true,
    animateOut: 'fadeOut',
    autoplayTimeout: 3000,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
})

//slider 2
var owl2 = $('.owl-carousel-cat');
owl2.owlCarousel({
    margin: 10,
    loop: true,
    nav: true,
    navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
    dots: false,
    autoplay: true,
    animateOut: 'fadeOut',
    autoplayTimeout: 3000,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        512: {
            items: 2
        },
        700: {
            items: 3
        },
        1000: {
            items: 4
        }
    }
})

// product slider_1
var owl2 = $('.owl-carousel-product');
owl2.owlCarousel({

    margin: 0,
    loop: true,
    nav: true,

    navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
    dots: false,
    autoplay: false,
    animateOut: 'fadeOut',
    autoplayTimeout: 3000,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        768: {
            items: 2
        },
        992: {
            items: 3
        },
        1400: {
            items: 4
        }
    }
})

// <!-- testimonial -->
    var owl2 = $('.owl-carousel-testimonial');
    owl2.owlCarousel({

        margin: 0,
        loop: true,
        nav: false,

        navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
        dots: true,
        autoplay: false,
        animateOut: 'fadeOut',
        autoplayTimeout: 3000,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            }
        }
    })

//blog
var owl = $('.owl-carousel-blog');
owl.owlCarousel({
    padding: 0,
    margin: 0,
    loop: true,
    nav: true,
    dots: true,
    navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
    autoplay: false,
    animateOut: 'fadeOut',
    autoplayTimeout: 3000,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1
        },
        768: {
            items: 2
        },
        1200: {
            items: 3
        }
    }
})


// manufacture
var owl2 = $('.owl-carousel-manufacturer');
owl2.owlCarousel({
    margin: 10,
    loop: true,
    nav: true,
    navText: ['<i class="fa fa-angle-left" aria-hidden="true">', '<i class="fa fa-angle-right" aria-hidden="true">'],
    dots: false,
    autoplay: false,
    animateOut: 'fadeOut',
    autoplayTimeout: 3000,
    responsiveClass: true,
    responsive: {
        0: {
            items: 2
        },
        512: {
            items: 2
        },
        812: {
            items: 3
        },
        1000: {
            items: 6
        }
    }
})
